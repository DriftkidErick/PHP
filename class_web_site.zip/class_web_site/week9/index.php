<?php
    include __DIR__ . '/../include//header.php'
?>
<h2>Week 9</h2>
<p>Welcome this is a placeholder for future assignments</p>
<?php include __DIR__ . '/../include/footer.php'; ?>