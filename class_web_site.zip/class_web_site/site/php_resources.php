<?php
    include __DIR__ . '/../include//header.php'; //Included header by TIM HENRY
?>

    <h2>PHP Resources</h2>

    <p>Here you can find online resources for better PHP understanding.</p>

    <ul>
        <li><a href="https://www.w3schools.com/php/"> W3School PHP Web Tutorial </a></li>

        <li><a href="https://www.phptutorial.net/">PHP Tutorial</a></li>

        <li><a href="https://www.javatpoint.com/php-tutorial"> JavaTPoint PHP Turtorial</a></li>
    </ul>

<?php include __DIR__ . '/../include/footer.php'; //Included footer by TIM HENRY?>