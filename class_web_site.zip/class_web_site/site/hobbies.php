<?php
    include __DIR__ . '/../include//header.php'; //Included header by TIM HENRY
?>
<h2>Heres something I like to do on my freetime</h2>

<ul>
    <li><a href="https://www.youtube.com/@GearsandGasoline" target="_blank">Automotive Youtube</a></li>

    <li><a href="https://www.grailed.com/" target="_blank">Shopping/Selling clothes</a></li>

    <li><a href="https://music.apple.com/us/listen-now?l=en-US" target="_blank">Listening to music</a></li>
</ul>

<?php include __DIR__ . '/../include/footer.php'; //Included footer by TIM HENRY ?>