<?php
  // This should already be loaded, but just in case
  include_once __DIR__ . '/functions.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Not The NEIT Library</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <style>
        .navbar {
            background-color: #343a40;
            border-radius: 0;
        }

        .navbar-brand {
            font-weight: bold;
            color: #fff;
        }

        .navbar-nav li a {
            color: #fff;
        }

        .navbar-nav li a:hover,
        .navbar-nav li.active a {
            color: #ffd700;
            background-color: #000;
        }

        .navbar-inverse .navbar-toggle {
            border-color: #fff;
        }

        .navbar-inverse .navbar-toggle:hover,
        .navbar-inverse .navbar-toggle:focus {
            background-color: #000;
        }
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>

<body>
    <nav class="navbar navbar-inverse">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="listTeams.php">Not NEIT Books</a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <?php
                    if (isUserLoggedIn()) {
                        ?>
                        <li><a href="logoff.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
                        <?php
                    }
                    ?>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">

