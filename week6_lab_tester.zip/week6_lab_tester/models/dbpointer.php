<?php
// This file is only to set up the database the application points to.
// Uncomment the database to use
// Comment out the other

//// ************************************
//// Development database
const DB_CONFIG_FILE = "./models/prod_dbconfig.ini";


?>