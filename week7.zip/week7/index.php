<?php
   header('Location: ./schools/login.php');
?>