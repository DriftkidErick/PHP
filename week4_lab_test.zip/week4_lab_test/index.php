<?php
  header('Location: viewTeams.php');  
?>