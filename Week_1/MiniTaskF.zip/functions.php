<?php
//Going to treat this as the index page like in the video

//Function 
function dd($val)
{
    echo '<pre>';
    die(var_dump($val));
    echo '</pre>';
}

?>