<?php

require_once 'functions.php';

$animals = ['dog', 'cat', 'chipmunk', 'turtle', 'shark'];

dd($animals);

//  require_once 'MiniTaskFDesign.php';

?>
