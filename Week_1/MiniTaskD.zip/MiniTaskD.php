<?php


//Create an associatve array about tasks

    $taskList = 
    [
        'Task' => 'Walk the dog',
        'Due' => 'Tonight By 5',
        'Assigned to' => 'Erick',
        'Completed' => 'No'       
    ];



    require_once 'MiniTaskDDesign.php';
?>