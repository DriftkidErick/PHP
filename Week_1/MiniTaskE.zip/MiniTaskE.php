<?php

$task =
[
    'Title' => 'Do Php Assignments',
    'Due' => 'Monday, April 2nd',
    'Assigned_To' => 'Erick C.',
    'Completed' => false,
    'Working_on_assignment' => true,
    'Walking_the_dog_later' => false

];

require_once 'MiniTaskEDesign.php'
?>