<?php

//With this page we create an array and then we add the information of the html page

    //Making an Array

    $animals = [
        'Dog',
        'Cat',
        'Mouse',
        'Moose',
        'Turtle',
        'Taco Bell Dog'

    ];


//Allows us to reference other page
require_once 'MiniTaskCDesign.php';

?>



